	(function( $, undefined ) {
		var support = {
			touch: "ontouchend" in document
		};

		$.mobile = $.mobile || {};
		$.mobile.support = $.mobile.support || {};
		$.extend( $.support, support );
		$.extend( $.mobile.support, support );
	}( jQuery ));
